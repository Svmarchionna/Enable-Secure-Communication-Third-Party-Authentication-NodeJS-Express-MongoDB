const express = require('express');
const Partner = require('../models/partner');
const authenticate = require('../authenticate');

const partnerRouter = express.Router();

partnerRouter.use(bodyParser.json());

partnerRouter.route('/')
.get((req, res, next) => {
    Partner.find()
    .then(Partners => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(Partners);
    })
    .catch(err => next(err));
})
.post(authenticate.verifyUser, (req, res, next) => {
    Partner.create(req.body)
    .then(Partner => {
        console.log('Partner Created ', Partner);
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(Partner);
    })
    .catch(err => next(err));
})
.put(authenticate.verifyUser, (req, res) => {
    res.statusCode = 403;
    res.end('PUT operation not supported on /Partners');
})
.delete(authenticate.verifyUser, (req, res, next) => {
    Partner.deleteMany()
    .then(response => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(response);
    })
    .catch(err => next(err));
});

PartnerRouter.route('/:PartnerId')
.get((req, res, next) => {
    Partner.findById(req.params.PartnerId)
    .then(Partner => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(Partner);
    })
    .catch(err => next(err));
})
.post(authenticate.verifyUser, (req, res) => {
    res.statusCode = 403;
    res.end(`POST operation not supported on /Partners/${req.params.PartnerId}`);
})
.put(authenticate.verifyUser, (req, res, next) => {
    Partner.findByIdAndUpdate(req.params.PartnerId, {
        $set: req.body
    }, { new: true })
    .then(Partner => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(Partner);
    })
    .catch(err => next(err));
})
.delete(authenticate.verifyUser, (req, res, next) => {
    Partner.findByIdAndDelete(req.params.PartnerId)
    .then(response => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(response);
    })
    .catch(err => next(err));
});

module.exports = partnerRouter;